# Telegram Account Reception Bot

Safe version: this project does not collect Telegram OTPs, 2FA passwords,
or Telegram session strings.

## Setup

1. Install Python 3.10+.
2. Install dependencies:

   pip install -r requirements.txt

3. Copy `.env.example` to `.env`.
4. Put your NEW BotFather token in `.env`.
5. Keep ADMIN_ID as your Telegram numeric ID.
6. Run:

   python bot.py

The SQLite database (`bot.db`) is created automatically.

## Security

Do not put API hashes, OTPs, 2FA passwords, or session strings in chat,
source code, or the database. If a real bot token/API hash was exposed,
rotate/revoke it and use fresh credentials.
