import os
import sqlite3
from dotenv import load_dotenv
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (
    Application, CommandHandler, MessageHandler,
    CallbackQueryHandler, ContextTypes, filters
)

load_dotenv()

BOT_TOKEN = os.getenv("BOT_TOKEN", "")
ADMIN_ID = int(os.getenv("ADMIN_ID", "0"))
DB_PATH = os.getenv("DB_PATH", "bot.db")


def db():
    conn = sqlite3.connect(DB_PATH)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS users (
            user_id INTEGER PRIMARY KEY,
            username TEXT,
            phone TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)
    conn.commit()
    return conn


def save_user(user_id, username):
    conn = db()
    conn.execute(
        "INSERT OR IGNORE INTO users(user_id, username) VALUES (?, ?)",
        (user_id, username)
    )
    conn.commit()
    conn.close()


async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    save_user(user.id, user.username or "")
    await update.message.reply_text(
        "Welcome to the account reception bot .\n\n"
        "-  To start, send the desired virtual account number "
        "or send /help for assistance."
    )


async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "Help\n\n"
        "Send your own phone number in international format.\n"
        "Example: +8801XXXXXXXXX\n\n"
        "For security, this bot does not collect Telegram OTP, "
        "2FA passwords, or session strings."
    )


async def number_received(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = (update.message.text or "").strip()

    if not text.startswith("+") or not text[1:].isdigit():
        await update.message.reply_text(
            "❌ Invalid number.\nExample: +8801XXXXXXXXX"
        )
        return

    user = update.effective_user
    conn = db()
    conn.execute(
        "INSERT OR IGNORE INTO users(user_id, username) VALUES (?, ?)",
        (user.id, user.username or "")
    )
    conn.execute(
        "UPDATE users SET phone=? WHERE user_id=?",
        (text, user.id)
    )
    conn.commit()
    conn.close()

    await update.message.reply_text(
        "✅ Number received.\n\n"
        "For security, this bot does not collect OTP, 2FA passwords, "
        "or Telegram session strings."
    )


async def admin(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id != ADMIN_ID:
        await update.message.reply_text("⛔ Access denied.")
        return

    keyboard = [
        [InlineKeyboardButton("📊 Statistics", callback_data="stats")],
        [InlineKeyboardButton("👥 Users", callback_data="users")],
    ]
    await update.message.reply_text(
        "🔐 Admin Panel",
        reply_markup=InlineKeyboardMarkup(keyboard)
    )


async def admin_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()

    if query.from_user.id != ADMIN_ID:
        await query.edit_message_text("⛔ Access denied.")
        return

    conn = db()

    if query.data == "stats":
        count = conn.execute("SELECT COUNT(*) FROM users").fetchone()[0]
        phones = conn.execute(
            "SELECT COUNT(*) FROM users WHERE phone IS NOT NULL"
        ).fetchone()[0]
        await query.edit_message_text(
            f"📊 Statistics\n\nUsers: {count}\nNumbers received: {phones}"
        )

    elif query.data == "users":
        rows = conn.execute(
            "SELECT user_id, username, phone FROM users ORDER BY created_at DESC LIMIT 20"
        ).fetchall()

        if not rows:
            text = "👥 No users yet."
        else:
            lines = ["👥 Recent users:\n"]
            for uid, username, phone in rows:
                lines.append(
                    f"• {uid} | @{username or 'none'} | {phone or 'not provided'}"
                )
            text = "\n".join(lines)

        await query.edit_message_text(text)

    conn.close()


def main():
    if not BOT_TOKEN:
        raise RuntimeError("BOT_TOKEN is missing in .env")
    if not ADMIN_ID:
        raise RuntimeError("ADMIN_ID is missing in .env")

    db()

    app = Application.builder().token(BOT_TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("help", help_command))
    app.add_handler(CommandHandler("admin", admin))
    app.add_handler(CallbackQueryHandler(admin_callback))
    app.add_handler(
        MessageHandler(filters.TEXT & ~filters.COMMAND, number_received)
    )

    print("Bot is running...")
    app.run_polling()


if __name__ == "__main__":
    main()
